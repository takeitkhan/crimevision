export const BASE_URL = "http://mathmozocms.test";

// export const BASE_URL = "http://admin.crimevision.news";
